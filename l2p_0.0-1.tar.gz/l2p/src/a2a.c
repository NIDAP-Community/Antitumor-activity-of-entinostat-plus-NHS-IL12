

/*
vi a2a.c ; gcc -minline-all-stringops -Wall -Os -o a2a a2asupport.c a2a.c
gcc -c -o  a2asupport.o a2asupport.c
gcc -minline-all-stringops -Wall -Os -o a2a a2asupport.o a2a.c

*/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <limits.h>
#include <math.h>
#include <ctype.h>
#include <errno.h>

#include "pathworks.h"

#ifdef L2P_USING_R
#include <R.h>
#include <Rdefines.h>
#endif

extern struct ens2gene_type ens2gene[];
extern struct a2a_type a2a[];
struct an_type
{
    char *name;
    unsigned int taxid;
};

struct an_type animals[] =
{
    { "canis familiaris" ,  9615 } ,
    { "danio rerio" , 7955 } ,
    { "drosophila melanogaster" ,  7227 } ,
    { "homo sapiens" , 9606 } ,
    { "macaca mulatta" , 9544 } ,
    { "mus musculus" , 10090 } ,
    { "oryctolagus cuniculus" , 9986 } ,
    { "pan troglodytes" , 9598 } ,
    { "rattus norvegicus" , 10116 } ,
    { (char *)0 , 0}
};

inline static int an2taxid(const char s[])
{
    int i;
    char t[100];

    strcpy(t,s);
// printf("in an2taxid [%s]\n",t); 
    if (strcmp(t,"dog") == 0) strcpy(t,"canis familiaris");
    else if (strcmp(t,"zebrafish") == 0) strcpy(t,"danio rerio");
    else if (strcmp(t,"fly") == 0) strcpy(t,"drosophila melanogaster");
    else if (strcmp(t,"fruitfly") == 0) strcpy(t,"drosophila melanogaster");
    else if (strcmp(t,"human") == 0) strcpy(t,"homo sapiens");
    else if (strcmp(t,"rhesus") == 0) strcpy(t,"macaca mulatta");
    else if (strcmp(t,"macaca") == 0) strcpy(t,"macaca mulatta");
    else if (strcmp(t,"macaque") == 0) strcpy(t,"macaca mulatta");
    else if (strcmp(t,"mouse") == 0) strcpy(t,"mus musculus");
    else if (strcmp(t,"rabbit") == 0) strcpy(t,"oryctolagus cuniculus");
    else if (strcmp(t,"chimp") == 0) strcpy(t,"pan troglodytes");
    else if (strcmp(t,"chimpanzee") == 0) strcpy(t,"pan troglodytes");
    else if (strcmp(t,"rat") == 0) strcpy(t,"rattus norvegicus");
    for (i=0;animals[i].name;i++)
    {
        if (strcmp(t,animals[i].name) == 0) return animals[i].taxid;
    }
fprintf(stderr,"ERROR invalid species %s [%s]\n",t,t);
    return -1;
}


#ifdef L2P_USING_R

SEXP a2afunc(SEXP lst,SEXP an1arg, SEXP an2arg)
{
    SEXP ret;
    int i,j,k;
    int len;
    int len2;
    char **z;      // input mouse gene symbols
    char **z2;     // output human gene symbols
    int outcnt = 0;
    int taxid1;    // taxonomy ikd
    int taxid2;
    char an1[PATH_MAX];
    char an2[PATH_MAX];
//    int gotone = 0;

    strncpy(an1,CHAR(STRING_ELT(an1arg, 0)),PATH_MAX-2);
    strncpy(an2,CHAR(STRING_ELT(an2arg, 0)),PATH_MAX-2);
    taxid1=an2taxid(an1);
    taxid2=an2taxid(an2);
    len = length(lst);
    len2 = len + 2000;
    z = (char **)malloc(sizeof(char *)*len);
    z2 = (char **)malloc(sizeof(char *)*len2);
    for (i = 0; i < len; i++) *(z+i) = strdup(CHAR(STRING_ELT(lst, i))); // malloc , be sure to free
    for (i = 0; i < len2; i++) *(z2+i) = (void *)0;

    outcnt = 0;
    for (j=0 ; j<len ; j++)
    {
        for (i=0 ; a2a[i].taxid1; i++)
        {
            if ( ( (taxid1 == a2a[i].taxid1) && (taxid2 == a2a[i].taxid2) ) || 
                 ( (taxid1 == a2a[i].taxid2) && (taxid2 == a2a[i].taxid1) ) 
               )
            {
                if (taxid1 == a2a[i].taxid1)
                {
                    if (strcmp(*(z+j),ens2gene[a2a[i].ensidx1].symbol) == 0)
                    {
                        *(z2+outcnt) = strdup(ens2gene[a2a[i].ensidx2].symbol); // malloc ,  be sure to free
                        outcnt++;
                    }
                }
                else if (taxid1 == a2a[i].taxid2)
                {
                    if (strcmp(*(z+j),ens2gene[a2a[i].ensidx2].symbol) == 0)
                    {
                        *(z2+outcnt) = strdup(ens2gene[a2a[i].ensidx1].symbol); // malloc ,  be sure to free
                        outcnt++;
                    }
                }
            }
        }
    }
    if (z) 
    { 
        for (k=0 ; k<len ; k++) 
	{ 
	    if (*(z+k)) free(*(z+k)); 
	}
	free(z); 
	z = (void *)0;  
    }

    PROTECT(ret = allocVector(STRSXP, outcnt));

    for (i = 0; i < outcnt; i++) 
    {
        if (*(z2+i)) { SET_STRING_ELT(ret,i, mkChar(*(z2+i)));}
    }
    if (z2) 
    { 
        for (k=0 ; k<len2 ; k++) 
	{ 
	    if (*(z2+k)) free(*(z2+k)); 
	}
	free(z2); 
	z2 = (void *)0;  
    }
    UNPROTECT(1);
    return ret;
#if 0
   PROTECT(mychar = allocVector(STRSXP, 1));
   SET_STRING_ELT(mychar, 0, mkChar("AAA"));
   UNPROTECT(1);
   return mychar;
#endif
}

#else
 // command line
int a2afunc_command_line(int taxid1, int taxid2)
{
    char nm[512]; // gene name
    int i,status;
    int outcnt = 0;
int dork;

    while ( fgets(nm, sizeof(nm), stdin) ) // gets() function is deprecated
    {
        for (i=0;nm[i];i++) { if ((nm[i] == '\r') || (nm[i] == '\n')) nm[i] = (char)0; }
        status = 0;
        for (i=0 ; a2a[i].taxid1; i++)
        {    // h fields are : int hid; int taxid; int egid; char *sym;
            if ( ( (taxid1 == a2a[i].taxid1) && (taxid2 == a2a[i].taxid2) ) || 
                 ( (taxid1 == a2a[i].taxid2) && (taxid2 == a2a[i].taxid1) ) 
               )
            {
dork = 0;
#if 0
if ((strcmp(nm,ens2gene[a2a[i].ensidx1].symbol) == 0) ||  (strcmp(nm,ens2gene[a2a[i].ensidx2].symbol) == 0))
{
printf("dork %d %d %s %s %d %d\n",taxid1,taxid2,ens2gene[a2a[i].ensidx1].symbol,ens2gene[a2a[i].ensidx2].symbol,a2a[i].taxid1,a2a[i].taxid2);
dork = 1;
//dork 10090 9606 PTEN Pten 9606 10090
}
#endif
                if (taxid1 == a2a[i].taxid1)
                {
if (dork)
{
printf("here0\n"); 
printf("here1\n"); 
printf("1 %d %d %s %s\n",taxid1,taxid2,ens2gene[a2a[i].ensidx1].symbol,ens2gene[a2a[i].ensidx2].symbol);
}
                    if (strcmp(nm,ens2gene[a2a[i].ensidx1].symbol) == 0)
    	            printf("%s\n",ens2gene[a2a[i].ensidx2].symbol);
                }
                else if (taxid1 == a2a[i].taxid2)
                {
if (dork)
{
printf("dork3 %d %d %s %s %d %d\n",taxid1,taxid2,ens2gene[a2a[i].ensidx1].symbol,ens2gene[a2a[i].ensidx2].symbol,a2a[i].taxid1,a2a[i].taxid2);
printf("here2\n"); 
printf("2 %d %d %s %s\n",taxid1,taxid2,ens2gene[a2a[i].ensidx1].symbol,ens2gene[a2a[i].ensidx2].symbol);
}
                    if (strcmp(nm,ens2gene[a2a[i].ensidx2].symbol) == 0)
	                printf("%s\n",ens2gene[a2a[i].ensidx1].symbol);
                }
                outcnt++;
            }
        }
    }
    return status;
}

int main(int argc,char *argv[])
{
//    char nm[512];  // gene name
    char an[512]; // source animal
    char an2[512]; // convert to this
    int taxid;
    int taxid2;

    if (argc != 3)
    {
        fprintf(stderr,"usage: a2a genename source_species destination_species\n");
        return 1;
    }
//    strcpy(nm,argv[1]); 
    strcpy(an,argv[1]);
    strcpy(an2,argv[2]);

    taxid = an2taxid(an);
    taxid2 = an2taxid(an2);
    a2afunc_command_line(taxid,taxid2);
    return 0;
}
#endif

